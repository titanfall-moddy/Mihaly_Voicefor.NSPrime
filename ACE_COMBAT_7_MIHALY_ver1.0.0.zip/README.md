Replaces Replaces Prime Northstar`s OS voice and sound effects to Mihaly from Ace Combat 7.

Include Miahly voice,tether trap,cluster missle,flight core salvo and plasma railgun`s fire/charge(every tick).

ATTENTION:If you want this mod exist with Mihaly voice for (normal) Northstar,please delete all files besides diag_gs_titanNorthstar....(Keep only one of the two sides,you can make your own decisions)

Happy hunting, ace.